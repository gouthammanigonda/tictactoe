matrix = []
for i in range(3):
    lists = input().split()
    matrix.append(lists)

row_list = []
for i in range(3):
    nested_list = []
    for row_ in matrix:
        row = row_[i]
        nested_list.append(row)
    row_list.append(nested_list)
    
diagonal_list = []
anti_diagonal_list = []
count = 0
count_a = 2
for lists in matrix:
    diagonal_list.append(lists[count])
    anti_diagonal_list.append(lists[count_a])
    count += 1
    count_a -= 1
    
col_list = matrix
row_list.extend(col_list)
row_list.append(diagonal_list)
row_list.append(anti_diagonal_list)
final_check = row_list.copy()
match_1 = ['X','X','X']
match_2 = ['O','O','O']
if match_1 in final_check:
    print("Anjali Wins")
elif match_2 in final_check:
    print("Abhinav Wins")
else:
    print("Tie")